SHIFT PLANNER SMART — Beta v0.1

Contenuto: PWA mobile-first con dashboard, turni, durata turno configurabile, ferie, sonno/recupero SMART, allenamenti e salvataggio locale.

Per provarla come app su iPhone serve pubblicare questa cartella su un hosting HTTPS. Poi aprire il sito in Safari > Condividi > Aggiungi alla schermata Home.

Nota: aprire index.html direttamente dai File di iPhone non abilita correttamente installazione/offline; serve un indirizzo HTTPS.
